1 � Le but du jeu
Le jeu vous place dans la peau d'un explorateur qui se retrouve bloqu� � l'entr�e d'un temple.
Vous devez alors contr�ler par ordinateur un petit robot, afin de trouver un moyen d'ouvrir la porte.
Celui-ci est capable de d�crire l'endroit o� il se situe, ramasser et poser des objets, ouvrir des portes
et des coffres, examiner des objets et bien s�r de se d�placer. Mais attention car � chaque
d�placement, la batterie diminue, et si elle tombe � z�ro le robot restera bloqu� dans le temple, et
vous ne pourrez jamais rentrer le chercher. Pensez donc � le ramener � l'entr�e du temple de temps
en temps afin de changer sa batterie.

2 � Les diff�rentes commandes
-help : donne la liste des commandes disponibles.
-batterie : donne la capacit� restante de la batterie.
-go "nom d'une salle" : permet de se d�placer dans une salle.
dalle : permet de se d�placer sur une dalle.
-look : donne un descriptif de la salle.
"nom d'un objet" : donne un descriptif d�taill� de l'objet.
robot : donne un descriptif du robot que vous contr�lez.
-open nom d'une salle [code]: ouvre la porte correspondant � la salle.
coffre : ouvre le coffre.
-put "droite|gauche" : permet de poser l'objet de la main choisie au sol.
-take "nom d'un objet" : permet de saisir un objet dans une main libre.
-quit : quitte le jeu.

3 - lancer le jeu
Pour lancer le jeu sous windows il suffit d'executer start.bat
Pour lancer le jeu sous Linux il faut exectuer la commande java -jar Jeu.jar

Pour recompiler le jeu depuis un terminal Linux il est n�cessaire d'uttiliser l'option "-encoding ISO-8859-1"
car le jeu poss�de des accent.